const express = require("express");
const { registerUser, loginUser, getUserProfile, refreshToken, invalidateToken } = require("../controllers/authController");
const { protect } = require("../middlewares/authMiddleware");

const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/refresh", refreshToken);
router.post("/invalidate", protect, invalidateToken);
router.get("/profile", protect, getUserProfile);

module.exports = router;
