const express = require("express");
const cors = require("cors");

console.log("APP: Loading dependencies");

let authRoutes, retailerRoutes, projectRoutes, messageRoutes, searchRoutes, analyticsRoutes;
try {
  authRoutes = require("./routes/authRoutes");
  retailerRoutes = require("./routes/retailerRoutes");
  projectRoutes = require("./routes/projectRoutes");
  messageRoutes = require("./routes/messageRoutes");
  searchRoutes = require("./routes/searchRoutes");
  analyticsRoutes = require("./routes/analyticsRoutes");
  console.log("APP: All routes loaded successfully");
} catch (err) {
  console.error("APP: Route loading failed:", err.message || err);
}

const { pool } = require("./config/db");

console.log("APP: configuring middleware");

// CORS configuration
const corsOptions = {
  origin: process.env.FRONTEND_URL || (process.env.NODE_ENV !== 'production' ? ['http://localhost:8080', 'http://127.0.0.1:8080', 'http://localhost:5173'] : false),
  credentials: true
};

const app = express();
app.use(cors(corsOptions));

// Limit request payload to 1MB to prevent memory bloat
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ limit: '1mb', extended: true }));

// Health-check route
app.get('/', (req, res) => {
  res.send('Backend is working');
});

// Routes (safe mounting)
if (authRoutes) app.use("/api/auth", authRoutes);
if (projectRoutes) app.use("/api/projects", projectRoutes);
if (retailerRoutes) app.use("/api/retailers", retailerRoutes);
if (messageRoutes) app.use("/api/messages", messageRoutes);
if (searchRoutes) app.use("/api/search", searchRoutes);
if (analyticsRoutes) app.use("/api/analytics", analyticsRoutes);

console.log("APP: All routes mounted");

// Test DB connection on startup (dev/non-production only)
if (process.env.NODE_ENV !== 'production' && pool) {
  (async () => {
    try {
      const conn = await pool.getConnection();
      console.log("✅ MySQL connected successfully");
      conn.release();
    } catch (err) {
      console.error("❌ Database connection error:", err.message);
    }
  })();
}

module.exports = app;
